Dubai Premium Hookah Lounge — Full Drawing Set
================================================

Contents of this ZIP (one complete image set):

CONCEPT RENDERS (PNG)
  01-rooftop-concept.png          Rooftop lounge atmosphere
  02-indoor-robot-concept.png     Indoor dining + fountain + robot
  03-building-section-concept.png Building section concept
  04-vip-room-concept.png         VIP suite (e-door closed + hostesses)

TECHNICAL DRAWINGS (SVG)
  01-indoor-floor-plan.svg        A-01 Indoor floor plan
  02-rooftop-floor-plan.svg       A-02 Rooftop floor plan
  03-robot-routing.svg            R-01 Robot routing & order flow
  04-section-elevation.svg        A-03 Building section
  05-vip-room-plan.svg            A-04 VIP suite (e-lock, TVs, VOD)
  06-emergency-room-plan.svg      A-05 Emergency / seizure room
  07-payment-system.svg           P-01 Electronic pay · no tip · donations

ALSO IN PACKAGE FOLDER (outside ZIP root if browsing repo)
  ../ARCHITECTURE-AND-COST.md
  ../index.html                   Interactive drawing board

PAYMENT POLICY (summary)
  - Strictly electronic (no cash)
  - No tipping (tip fields disabled; staff cannot accept tips)
  - Optional donations only — to house fund / partner charity, never to individuals

Concept package only — not construction documents.
