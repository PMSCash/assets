EJL Lighthouse — Full Drawing Set
=================================

House: EJL Lighthouse (Dubai)
Brand: Flashy pink + gold · logo on robots

CONCEPT / BRAND (PNG)
  ejl-lighthouse-logo.png         Brand logo (pink + gold)
  05-vip-ejl-concept.png          VIP: fountain · fireplace · pole
  01-rooftop-concept.png          Rooftop atmosphere
  02-indoor-robot-concept.png     Indoor dining + robot
  03-building-section-concept.png Building section concept
  04-vip-room-concept.png         Earlier VIP concept

TECHNICAL DRAWINGS (SVG)
  ejl-lighthouse-logo.svg         Brand logo
  01-indoor-floor-plan.svg        A-01 Indoor floor plan
  02-rooftop-floor-plan.svg       A-02 Rooftop floor plan
  03-robot-routing.svg            R-01 Robot routing
  04-section-elevation.svg        A-03 Building section
  05-vip-room-plan.svg            A-04 VIP (fountain/fireplace/pole)
  06-emergency-room-plan.svg      A-05 Emergency / seizure room
  07-payment-system.svg           P-01 E-pay · no tip · donations
  08-robot-branding.svg           B-01 Robot pink/gold livery

ALSO
  ARCHITECTURE-AND-COST.md
  index.html

PAYMENT
  - Strictly electronic (no cash)
  - No tipping
  - Donations only (house fund / charity)

Concept package only — not construction documents.
